import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Background from "./components/Background";
import MouseGlow from "./components/MouseGlow";

function App() {
  return (
    <div className="relative overflow-hidden bg-[#030712] min-h-screen">

      {/* Animated Background */}
      <Background />

      {/* Mouse Glow */}
      <MouseGlow />

      <Navbar />
      <Hero />
      <Features />

    </div>
  );
}

export default App;
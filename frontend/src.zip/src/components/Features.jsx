import { FaRobot, FaFilePdf, FaClipboardCheck } from "react-icons/fa";
import FeatureCard from "./FeatureCard";

function Features() {
  return (
    <section className="max-w-7xl mx-auto px-8 py-20">

      <h2 className="text-4xl font-bold text-center mb-14">
        Powerful AI Features
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 justify-items-center">

        <FeatureCard
          icon={<FaFilePdf />}
          title="Upload PDFs"
          description="Upload your notes and let AI understand them."
        />

        <FeatureCard
          icon={<FaRobot />}
          title="AI Chat"
          description="Ask questions from your study material instantly."
        />

        <FeatureCard
          icon={<FaClipboardCheck />}
          title="Quiz Generator"
          description="Generate quizzes automatically from your notes."
        />

      </div>

    </section>
  );
}

export default Features;
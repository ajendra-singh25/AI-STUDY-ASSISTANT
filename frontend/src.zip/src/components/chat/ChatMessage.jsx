import { FaRobot, FaUser } from "react-icons/fa";

function ChatMessage({ sender, text }) {
  const isUser = sender === "user";

  return (
    <div
      className={`flex mb-6 ${
        isUser ? "justify-end" : "justify-start"
      }`}
    >
      <div
        className={`
          max-w-[70%]
          rounded-2xl
          p-4
          flex
          gap-4
          ${
            isUser
              ? "bg-cyan-500 text-black"
              : "bg-white/10 text-white"
          }
        `}
      >
        {!isUser && (
          <FaRobot className="text-cyan-400 text-xl mt-1" />
        )}

        <p>{text}</p>

        {isUser && (
          <FaUser className="text-black text-xl mt-1" />
        )}
      </div>
    </div>
  );
}

export default ChatMessage;
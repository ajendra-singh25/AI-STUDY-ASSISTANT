import { motion } from "framer-motion";
import { useState } from "react";
import DashboardPreview from "./DashboardPreview";

function Hero() {
    const [mousePosition, setMousePosition] = useState({
  x: 0,
  y: 0,
});
const handleMouseMove = (e) => {
  const rect = e.currentTarget.getBoundingClientRect();

  setMousePosition({
    x: e.clientX - rect.left,
    y: e.clientY - rect.top,
  });
};
  return (
    <motion.section
      initial={{ opacity: 0, y: 80 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 1 }}
      onMouseMove={handleMouseMove}
      className="
        relative
        overflow-hidden
        min-h-screen
        max-w-7xl
        mx-auto
        px-8
        flex
        flex-col
        lg:flex-row
        items-center
        justify-between
        gap-16
      "
    >

      {/* STEP 3 STARTS HERE */}

      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.2, 0.35, 0.2],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="
          absolute
          -top-40
          -left-40
          w-96
          h-96
          bg-cyan-500/20
          rounded-full
          blur-3xl
        "
      />

      <motion.div
        animate={{
          scale: [1.1, 0.9, 1.1],
          opacity: [0.15, 0.3, 0.15],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="
          absolute
          bottom-0
          right-0
          w-[500px]
          h-[500px]
          bg-blue-600/20
          rounded-full
          blur-3xl
        "
      />
<motion.div
    animate={{
        x: mousePosition.x - 200,
        y: mousePosition.y - 200,
    }}
    transition={{
        type: "spring",
        stiffness: 60,
        damping: 20,
    }}
    className="
        absolute
        w-[400px]
        h-[400px]
        rounded-full
        bg-cyan-500/10
        blur-[120px]
        pointer-events-none
    "
/>
      {/* STEP 3 ENDS HERE */}

      {/* Hero Text */}
      <div className="flex-1 max-w-3xl">

    <h1 className="text-7xl font-black leading-tight">
        Study <span className="text-cyan-400">Smarter</span> with AI
    </h1>

    <p className="mt-6 text-slate-300 text-xl max-w-2xl">
        Upload PDFs, generate notes, create quizzes,
        and chat with your study material using AI.
    </p>

    <div className="mt-10 flex gap-5">

        <button className="bg-cyan-500 hover:bg-cyan-400 text-black font-bold px-8 py-3 rounded-xl transition hover:scale-105">
            Get Started
        </button>

        <button className="border border-cyan-400 text-cyan-400 px-8 py-3 rounded-xl hover:bg-cyan-400 hover:text-black transition">
            Watch Demo
        </button>

    </div>

</div>

      {/* Dashboard */}
      <div className="flex-1 flex justify-center">
        <DashboardPreview />
      </div>

    </motion.section>
  );
}

export default Hero;
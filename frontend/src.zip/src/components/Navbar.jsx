function Navbar() {
  return (
    <nav
  className="
  sticky
  top-0
  z-50
  backdrop-blur-xl
  bg-slate-950/40
  border-b
  border-white/10
"
>
    <nav className="
max-w-7xl
mx-auto
px-8
py-5
flex
justify-between
items-center
"></nav>
    

      <div className="max-w-7xl mx-auto px-8 py-5 flex items-center justify-between">

        <h1 className="text-3xl font-bold text-cyan-400">
          AI Study
        </h1>

        <ul className="flex gap-10 text-slate-300">

          <li className="cursor-pointer hover:text-cyan-400 transition">
            Features
          </li>

          <li className="cursor-pointer hover:text-cyan-400 transition">
            Pricing
          </li>

          <li className="cursor-pointer hover:text-cyan-400 transition">
            About
          </li>

        </ul>

        <button className="bg-cyan-500 hover:bg-cyan-400 text-black px-6 py-2 rounded-xl font-semibold transition hover:scale-105">
          Login
        </button>

      </div>

    </nav>
  );
}

export default Navbar;